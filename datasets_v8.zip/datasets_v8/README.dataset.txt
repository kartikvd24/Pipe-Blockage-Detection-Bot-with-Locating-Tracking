# Sewer Defects > 2023-04-17 1:55pm
https://universe.roboflow.com/sewage-defect-detection-s68df/sewer-defects-u8zwz

Provided by a Roboflow user
License: CC BY 4.0

